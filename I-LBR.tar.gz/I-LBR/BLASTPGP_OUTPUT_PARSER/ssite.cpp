/*
===============================================================================
   This program (S-SITE) was written by Jianyi Yang at the
   Yang Zhang lab
   Department of Computational Medicine and Bioinformatics 
   University of Michigan 
   100 Washtenaw Avenue, Ann Arbor, MI 48109-2218 
                                                               
   Reference: J Yang, A Roy, Y Zhang. Protein-ligand binding site recognition 
   using complementary binding-specific substructure comparison and sequence 
   profile alignment, Bioinformatics, 29:2588-2595 (2013).

   Please report bugs and questions to yangji@umich.edu or yang0241@e.ntu.edu.sg
================================================================================
*/

#include <map>
#include<fstream>
#include<iostream>
#include<iomanip>
#include<cstring>
#include<sstream>
#include<cstdlib>
#include<vector>
#include<list>
#include<map>
#include<set>
#include<bitset>
#include<ctime>
#include<cmath>
#include<algorithm>

#define NEG_INF -100
#define POS_INF 100

using namespace std;

double wss, wbs, wshift, gapo, gape;
double blosum62[23][23];


class Element
{
public:
        double val[4]; //1-->m, 2-->ix, 3-->iy, the scores in each element of each of the three matrices, M, Ix, Iy
        int p[4]; //points to previous step status
        //possible values for pointer p[1] (M): 1-->M (Match), 2-->Ix (Insertion in X), 3-->Iy (Insertion in Y)
        //possible values for pointer p[2] (Ix): 1-->M (Match), 2-->Ix (Insertion in X)
        //possible values for pointer p[3] (Iy): 1-->M (Match), 3-->Iy (Insertion in Y)
};




template <class A> void NewArray(A *** array, int Narray1, int Narray2)
{ 
  *array=new A* [Narray1];
  for(int i=0; i<Narray1; i++) *(*array+i)=new A [Narray2];
};

template <class A> void DeleteArray(A *** array, int Narray)
{ 
  for(int i=0; i<Narray; i++) 
    if(*(*array+i)) delete [] *(*array+i);
  if(Narray) delete [] (*array);
  (*array)=NULL;
};

void load_blosum62();

void print_help()
{
     printf("Usage:\n");
     printf("./SSITE query.profile frag.dat template.lst PSSM_dir wss wbs wshift gapo gap2\n");
     printf("./SSITE query.profile frag.dat template.lst PSSM_dir wss wbs wshift gapo gap2 saveresultpath\n");
     exit(1); 
}

int AA2Num(char AA)
{
        int i=-1;

        if(AA=='A')
                i=0;
        else if(AA=='R')
                i=1;
        else if(AA=='N')
                i=2;
        else if(AA=='D')
                i=3;
        else if(AA=='C')
                i=4;
        else if(AA=='Q')
                i=5;
        else if(AA=='E')
                i=6;
        else if(AA=='G')
                i=7;
        else if(AA=='H')
                i=8;
        else if(AA=='I')
                i=9;
        else if(AA=='L')
                i=10;
        else if(AA=='K')
                i=11;
        else if(AA=='M')
                i=12;
        else if(AA=='F')
                i=13;
        else if(AA=='P')
                i=14;
        else if(AA=='S')
                i=15;
        else if(AA=='T')
                i=16;
        else if(AA=='W')
                i=17;
        else if(AA=='Y')
                i=18;
        else if(AA=='V')
                i=19;
        else if(AA=='B')
                i=20;
        else if(AA=='Z')
                i=21;
        else if(AA=='X')
                i=22;
		else
		{
			printf("unknown residues %c\n", AA);
			exit(1);
		}

        return i;
}


void output_align1(int *invmap0, int len)
{
	for(int i=0; i<len; i++)
	{
		if(invmap0[i]>=0)
		{
			printf("%3d ", invmap0[i]+1);
		}
		else
		{
			printf("%3d ", invmap0[i]);
		}		
	}
	cout << endl << endl;
}

void output_align1(int *invmap0, int len, vector <int> mapp)
{
	for(int i=0; i<len; i++)
	{
		if(invmap0[i]>=0)
		{
			printf("%3d ", mapp[invmap0[i]]+1);
		}
		else
		{
			printf("%3d ", invmap0[i]);
		}		
	}
	cout << endl << endl;
}

void output_sec(vector <int> invmap0, int len)
{
	for(int i=0; i<len; i++)
	{
		printf("%3d ", invmap0[i]);
	}
	cout << endl << endl;
}


int load_query(char *query, vector <int> *sec, vector < vector <float> > *freq, vector <char> *seq)
{
	FILE *fp=fopen(query, "r");
	if(fp==NULL)
	{
		printf("error open query\n");
		exit(1);
	}
	char str[5000];
	while(fgets(str, 5000, fp)!=NULL)
	{
		if(strlen(str)<20)
		{
			continue;
		}

		float r[20];
		int ss;
		char res;
		sscanf(str, "%c %d %f %f %f %f %f  %f %f %f %f %f  %f %f %f %f %f  %f %f %f %f %f", &res, &ss, &r[0], &r[1], &r[2], &r[3], &r[4], &r[5], &r[6], &r[7], &r[8], 
			   &r[9], &r[10], &r[11], &r[12], &r[13], &r[14], &r[15], &r[16], &r[17], &r[18], &r[19]);		
		(*seq).push_back(res);
		(*sec).push_back(ss);
		vector <float> rr;
		rr.assign(r, r + 20);
		(*freq).push_back(rr);
	}

	fclose(fp);
	return ((*sec).size());
}

// load the template protein's secondary structure (sec), sequence (seq), pssm (freq), and the binding information
int load_template(char *name, char *pssmdir, vector <int> *sec, vector < vector <int> > *freq, vector <int> *Bsite, vector <char> *seq)
{	
	char buffer[5000];
	sprintf(buffer, "%s/%s", pssmdir, name);
	FILE *fp=fopen(buffer, "r");
	if(fp==NULL)
	{
		printf("can not open %s\n", buffer);
		exit(1);
	}
	char str[5000];
	while(fgets(str, 5000, fp)!=NULL)
	{
		if(strlen(str)<20)
		{
			continue;
		}

		int r[20];
		int ss, b;
		char res;
		sscanf(str, "%c %d %d %d %d %d %d  %d %d %d %d %d  %d %d %d %d %d  %d %d %d %d %d %d", &res, &ss, &r[0], &r[1], &r[2], &r[3], &r[4], &r[5], &r[6], &r[7], &r[8], 
			   &r[9], &r[10],&r[11], &r[12], &r[13], &r[14], &r[15], &r[16], &r[17], &r[18], &r[19], &b);
		
		(*seq).push_back(res);
		(*sec).push_back(ss);
		(*Bsite).push_back(b);
		vector <int> rr;
		rr.assign(r, r + 20);
		(*freq).push_back(rr);
	}
	fclose(fp);
	
	return ((*sec).size());
}


void score_matrix(vector < vector <float> > qfreq, vector < vector <int> > tfreq, vector < vector <double> > *score)
{
	for(int i=0; i<qfreq.size(); i++)
	{
		vector <double> score1;
		for(int j=0; j<tfreq.size(); j++)
		{
			double sum=0;
			for(int k=0; k<20; k++)
			{
				sum += qfreq[i][k]*tfreq[j][k];
			}			
			score1.push_back(sum);
		}
		(*score).push_back(score1);
	}	
}


int max_index(double x[], int start, int end)
{
	int idx, i;
	double max_x=x[start];
	idx=start;

	for(i=start; i<=end; i++)
	{
		if(x[i]>=max_x)
		{
			max_x=x[i];
			idx=i;
		}
	}

	return idx;
}

int delta(int i, int j)
{
	if(i==j)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}




//general version of SWDP
double DP1(vector <int> qsec, vector <int> tsec, vector <int> bsite, double gap_open, double gap_ext, int q2t[], vector < vector <double> > score, vector <char> qseq, vector <char> tseq)
{
	//SW dynamic programming for fragment alignment, qsec is the fragment secondary structure of query, tsec is the whole chain of template
    //Input: scoring matrix, gap_open, and gap_ext, fragment starting and end numbers, code from 1 to L
    //Output: the aligned sequences: seq1A, and seq2A

	Element **mat;	
	int i, j;
	int len1=qsec.size();
	int len2=tsec.size();
	NewArray(&mat, len1+1, len2+1); 

	//printf("%d %d\n", len1, len2);

	//initialization
	mat[0][0].val[1]=0;
	mat[0][0].val[2]=0;
	mat[0][0].val[3]=0;
	q2t[0]=-1;
	for(j=1; j<=len2; j++)
	{
		mat[0][j].val[1]=0;
		mat[0][j].val[2]=0;
		mat[0][j].val[3]=0;
		mat[0][j].p[3]=0;
	}

	for(i=1; i<=len1; i++)
	{
		mat[i][0].val[1]=0;
		mat[i][0].val[2]=0;
		mat[i][0].p[2]=0;
		mat[i][0].val[3]=0;
		q2t[i]=-1;
	}


    int i_max, j_max, dir=-1;
    double s_max=-1;
	//decide matrix and path	
	double d, x, y, scoreij;
	double gopen, gext;
	for(i=1; i<=len1; i++)
	{
		for(j=1; j<=len2; j++)
		{
			//for M
			scoreij = score[i-1][j-1] + wss*delta(qsec[i-1], tsec[j-1]) + wbs*bsite[j-1]*blosum62[AA2Num(qseq[i-1])][AA2Num(tseq[j-1])] + wshift;
			//cout << scoreij << endl;
			
			d=mat[i-1][j-1].val[1]+scoreij;
			x=mat[i-1][j-1].val[2]+scoreij;
			y=mat[i-1][j-1].val[3]+scoreij;

			if(d>x && d>y)
			{
                if(d<0)
                {
                    mat[i][j].val[1]=0;
                }
                else
                {
				    mat[i][j].val[1]=d;
				    mat[i][j].p[1]=1;

					if(s_max < mat[i][j].val[1])
					{
						s_max=mat[i][j].val[1];
						i_max=i;
						j_max=j;
						dir=1;
					}
                }
			}
			else if(x>y)
			{						
                if(x<0)
                {
                    mat[i][j].val[1]=0;
                }
                else
                {
				    mat[i][j].val[1]=x;
				    mat[i][j].p[1]=2;

					if(s_max < mat[i][j].val[1])
					{
						s_max=mat[i][j].val[1];
						i_max=i;
						j_max=j;
						dir=1;
					}
                }				
			}
			else
			{
                if(y<0)
                {
                    mat[i][j].val[1]=0;
                }
                else
                {
				    mat[i][j].val[1]=y;
				    mat[i][j].p[1]=3;

					if(s_max < mat[i][j].val[1])
					{
						s_max=mat[i][j].val[1];
						i_max=i;
						j_max=j;
						dir=1;
					}
                }      
			}

			//for Ix, the best score given that xi is aligned to a gap
			if(j>=len2)
			{
				gopen=0;
				gext=0;
			}
			else if(tsec[j-1] == tsec[j] && tsec[j-1]!=1) //my version
			//else if(tsec[j-1] == qsec[i-1] && tsec[j-1]!=1) //inside template RSSE
			{
				gopen = NEG_INF;
				gext  = NEG_INF;
			}
			else
			{
				gopen=gap_open;
				gext=gap_ext;
			}
			d=mat[i-1][j].val[1]+gopen;
			x=mat[i-1][j].val[2]+gext;
		
			if(d>x)
			{
                if(d<0)
                {
                    mat[i][j].val[2]=0;
                }  
                else
                {
				    mat[i][j].val[2]=d;
				    mat[i][j].p[2]=1;

					if(s_max < mat[i][j].val[2])
					{
						s_max=mat[i][j].val[2];
						i_max=i;
						j_max=j;
						dir=2;
					}
                }
			}
			else
			{
                if(x<0)
                {
                    mat[i][j].val[2]=0;
                }  
                else
                {
				    mat[i][j].val[2]=x;
				    mat[i][j].p[2]=2;    

					if(s_max < mat[i][j].val[2])
					{
						s_max=mat[i][j].val[2];
						i_max=i;
						j_max=j;
						dir=2;
					}                
                }  
			}


			//for Iy, the best score given that yj is aligned to a gap
			if(i>=len1)
			{
				gopen=0;
				gext=0;
			}
			else if(qsec[i-1] == qsec[i] && qsec[i-1]!=1) //my version
			//else if(tsec[j-1] == qsec[i-1] && tsec[j-1]!=1) //inside template RSSE
			{
				gopen = NEG_INF;
				gext  = NEG_INF;
			}
			else
			{
				gopen=gap_open;  //insert gap in coil region
				gext=gap_ext;
			}
			//cout << i << " " << j << " " << gopen << " " << d << " " << x << endl;

			d=mat[i][j-1].val[1]+gopen;
			y=mat[i][j-1].val[3]+gext;
			if(d>y)
			{
                if(d<0)
                {
                    mat[i][j].val[3]=0;
                }
                else
                {
                    mat[i][j].val[3]=d;
				    mat[i][j].p[3]=1;

					if(s_max < mat[i][j].val[3])
					{
						s_max=mat[i][j].val[3];
						i_max=i;
						j_max=j;
						dir=3;
					}
                } 
			}
			else
			{
                if(y<0)
                {
                    mat[i][j].val[3]=0;
                }
                else
                {
                    mat[i][j].val[3]=y;
				    mat[i][j].p[3]=3;

					if(s_max < mat[i][j].val[3])
					{
						s_max=mat[i][j].val[3];
						i_max=i;
						j_max=j;
						dir=3;
					}
                }
			}
		} //for i
	} //for j

	


	//global alignment score
	//int idx_max=max_index(mat[len1][len2].val, 1, 3);
	//double score0=mat[len1][len2].val[idx_max];

	double score0=0;
	if(dir!=-1)
	{
		int idx_max=dir;	
		score0=mat[i_max][j_max].val[idx_max];
		
		//cout << score0 << endl;
		//trace back to extract the alignment
		
		i=i_max;
		j=j_max;    
		int k=0; //the alignment order
		int path;
		path=idx_max;
		while(i>0 && j>0)
		{
			//record for the next step
			if(path==1) //a match state
			{
				path=mat[i][j].p[path];
				
				q2t[i-1]=j-1;				
				i--;
				j--;
			}
			else if(path==2) //seq 
			{
				path=mat[i][j].p[path];
				i--;
			}
			else if(path==3) //seq 
			{
				path=mat[i][j].p[path];
				j--;
			}	
			else
			{
				break;
			}
		}		
	}
	DeleteArray(&mat, len1+1);
	return score0;
}

int find_pair_b(int *q2t, int len, int q)
{
	int t=-1;
	if(q2t[q]>=0)
	{
		t=q2t[q]+1;	//start position for running DP
	}
	else
	{
		for(int i=q; i>=0; i--)
		{			
			if(q2t[i]>=0)
			{
				t=q2t[i]+1; //start position for running DP
				break;
			}			
		}
	}	

	return t;
}




int find_pair_f(int *q2t, int len, int q)
{
	int t=-1;
	if(q2t[q]>=0)
	{
		t=q2t[q]-1;	//end position for running DP
	}
	else
	{
		for(int i=q; i<len; i++)
		{			
			if(q2t[i]>=0)
			{
				t=q2t[i]-1;//end position for running DP
				break;
			}			
		}
	}	

	return t;
}

int get_align_len_full(int q2t[], int qlen, int tlen)
{
	int alen=qlen;
	int i, j0=-1, j1=-1;
	for(i=0; i<qlen; i++)
	{
		j1=q2t[i];
		//cout << i << " " << j0 << " "  << j1 << endl;
		if(j1!=-1)
		{
			if(j1<j0+1)
			{
				printf("wrong alignment i=%d, j1=%d j0=%d\n", i, j1, j0);
				//break;
				//output_align1(q2t, qlen);
				exit(1);
				alen=-1;
			}
			alen += j1-j0-1;
			j0=j1;
		}
	}

	if(j0<tlen-1)
	{
		//tail gap
		alen += tlen-1 - j0 -1;
	}

	return alen;
}

int get_align_len(int q2t[], int qlen, int tlen)
{
	int alen=0;
	int i, j0=-1, j1=-1;
	for(i=0; i<qlen; i++)
	{
		j1=q2t[i];
		//cout << i << " " << j0 << " "  << j1 << endl;
		if(j1!=-1)
		{			
			if(j1<j0+1)
			{
				printf("wrong alignment i=%d, j1=%d j0=%d\n", i, j1, j0);
				break;
				//output_align1(q2t, qlen);
				//exit(1);
				alen=-1;
			}						



			if(i==0) //ignore ending gaps
			{
				//cout << "ignore begining gaps " << j1 << endl;
				alen += 1;
			}
			else
			{
				//cout  << j0 << " "<< j1 << endl;
				alen += j1-j0;
			}

			j0=j1;
		}
		else
		{
			if(j0>=0 && j0<(tlen-1)) //ignore ending gaps
			{
				alen++;
			}
			else
			{
				//	cout << "ignore begining gap " << i << endl;
			}
		}
	}

	if(j0<tlen-1)
	{
		//cout << "ignore tail gap" << endl;
		//tail gap
		//alen += tlen-1 - j0;
	}

	return alen;
}



map <int, double> chain_align(vector < vector <double> > score, vector <int> qsec, vector <char> qseq,  vector <int> tsec, vector <char> tseq, vector <int> bsite, double *ras0, double *sia0, double *sib0, double *cov0, double *lcov0)
{
	//align whole query chain profile with one template profile

	map <int, double> p0;
	*sia0=0;
	*sib0=0;
	*cov0=0;
	*ras0=0;
	int *q2t=new int [qsec.size()+1];
	double rawscore=DP1(qsec, tsec, bsite, gapo, gape, q2t, score, qseq, tseq);
	//output_align1(j2i, tsec.size());
	//output_sec(tsec, tsec.size());
	//output_sec(qsec, qsec.size());

	//transfer binding site now
	map <int, double> p;	
	double eff=0, sia=0;
	double f=0;
	int count=0, count1=0;
	//cout << "Bsites: ";	
	int tBSR=0;
	for(int j=0; j<tsec.size(); j++)
	{
		if(bsite[j]==1)
		{
			tBSR++;
		}
	}
	for(int j=0; j<qsec.size(); j++)
	{
		int k=q2t[j];

		if(k>=0)
		{
			count1++;
			f=blosum62[AA2Num(qseq[j])][AA2Num(tseq[k])];
			sia += f;
			if(bsite[k]==1)
			{
				count++;								
				p[j+1]=f;
				eff += f;
			}
		}
	}	

	*lcov0 = count*1.0/tBSR;	
	if(count!=0)
	{
		p0=p;
		*sib0=eff/count;		
	}
	if(count1!=0)
	{
		*sia0 = sia/count1;
		*cov0 = count1*1.0/qsec.size();
	}


	int align_len=get_align_len(q2t, qsec.size(), tsec.size());
	double ras1=0;
	if(align_len<=0)
	{
		*ras0=0;
	}
	else
	{
		double ras = rawscore/align_len;
		ras1=1.0/(1.0+exp(-ras));
		*ras0 = ras;
	}


	delete [] q2t;		


	//	map <int, double>::iterator it;
	//	cout << score1 << endl;
	//	for(it = p0.begin(); it != p0.end(); ++it)
	//	{
	//		cout << it->first << " " << it->second << endl;
	//	}

	return p0;
}




map <int, double> align(char *temp, char *pssmdir, vector <char> qseq, vector <int> qsec, vector < vector <float> > qfreq, double *ras0, double *sia0, double *sib0, double *cov0, double *lcov0)
{
	vector <char> tseq;
	vector <int> tsec;
	vector <int> bsite;
	vector < vector <int> > tfreq;
	map <int, double> p0;

	//load template profile
	int tlen = load_template(temp, pssmdir, &tsec, &tfreq, &bsite, &tseq);
	//cout << tlen << endl;

	//compute the scoring matrix for DP
	vector < vector <double> > score;
	score_matrix(qfreq, tfreq, &score);
	p0=chain_align(score, qsec, qseq, tsec, tseq, bsite, ras0, sia0, sib0, cov0, lcov0);

	return p0; 
}

int main(int argc, char *argv[])
{
    if (argc < 9) 
    {
        print_help();
    }

	char list[2000], pssmdir[2000], query[2000], fragments[2000], saveresultpath[2000];
	strcpy(query, argv[1]); //query profile
	strcpy(list, argv[2]); //template list
	strcpy(pssmdir, argv[3]); //template pssm path


	//set parameters here
	//	wss=1.0; //weight for secondary structure
	//	wbs=1.0; //weight for binding site residues
	//	wshift=1.0; //weight for shift
	//	gapo=-5.0; //weight for gap open
	//	gape=-1.0; //weight for gap extension


	//set parameters here
	wss=atof(argv[4]); //weight for secondary structure
	wbs=atof(argv[5]); //weight for binding site residues
	wshift=atof(argv[6]); //weight for shift
	gapo=atof(argv[7]); //weight for gap open
	gape=atof(argv[8]); //weight for gap extension
	
	if (argc > 9){
		strcpy(saveresultpath, argv[9]);
	}else{
		strcpy(saveresultpath, "sresult.dat");
	}
	
	

	vector <char> qseq;
	vector <int> qsec;
	vector < vector <float> > qfreq;
	//load query profile
	int qlen=load_query(query, &qsec, &qfreq, &qseq);
	//cout << qlen << endl;


	load_blosum62();
	FILE *flist=fopen(list, "r");
	if(flist==NULL)
	{
		printf("can not open %s!\n", list);
		exit(1);
	}

	FILE *fresult;
	fresult=fopen(saveresultpath, "w");
	if(fresult==NULL)
	{
		printf("can not open sresult.dat!\n");
		exit(1);
	}


	char name[2000];
	char str[5000];
	double ras, sia, sib, cov, lcov;
	while(fgets(str, 5000, flist)!=NULL)
	{		
		sscanf(str, "%s", name);
		//cout << name << " ";
		fprintf(fresult, "%s:", name);
		strcat(name, ".pssm");
		map <int, double> p0=align(name, pssmdir, qseq, qsec, qfreq, &ras, &sia, &sib, &cov, &lcov);

		fprintf(fresult, "%.3f:%.3f:%.3f:%.3f:%.3f:", ras, sia, cov, sib, lcov);
		for( map <int, double>::iterator it = p0.begin(); it != p0.end(); ++it)
		{
			fprintf(fresult, "%d,", it->first);
		}
		fprintf(fresult, "\n");
	}

	fclose(fresult);	
	return 0; 
}








































void load_blosum62()
{
	blosum62[ 0][ 0]=1.000; blosum62[ 0][ 1]=0.286; blosum62[ 0][ 2]=0.143; blosum62[ 0][ 3]=0.143; blosum62[ 0][ 4]=0.429; blosum62[ 0][ 5]=0.286; blosum62[ 0][ 6]=0.286; blosum62[ 0][ 7]=0.429; blosum62[ 0][ 8]=0.143; blosum62[ 0][ 9]=0.286; blosum62[ 0][10]=0.286; blosum62[ 0][11]=0.286; blosum62[ 0][12]=0.286; blosum62[ 0][13]=0.143; blosum62[ 0][14]=0.286; blosum62[ 0][15]=0.571; blosum62[ 0][16]=0.429; blosum62[ 0][17]=0.000; blosum62[ 0][18]=0.143; blosum62[ 0][19]=0.429; blosum62[ 0][20]=0.143; blosum62[ 0][21]=0.286; blosum62[ 0][22]=0.429; 
	blosum62[ 1][ 0]=0.250; blosum62[ 1][ 1]=1.000; blosum62[ 1][ 2]=0.375; blosum62[ 1][ 3]=0.125; blosum62[ 1][ 4]=0.000; blosum62[ 1][ 5]=0.500; blosum62[ 1][ 6]=0.375; blosum62[ 1][ 7]=0.125; blosum62[ 1][ 8]=0.375; blosum62[ 1][ 9]=0.000; blosum62[ 1][10]=0.125; blosum62[ 1][11]=0.625; blosum62[ 1][12]=0.250; blosum62[ 1][13]=0.000; blosum62[ 1][14]=0.125; blosum62[ 1][15]=0.250; blosum62[ 1][16]=0.250; blosum62[ 1][17]=0.000; blosum62[ 1][18]=0.125; blosum62[ 1][19]=0.000; blosum62[ 1][20]=0.375; blosum62[ 1][21]=0.500; blosum62[ 1][22]=0.250; 
	blosum62[ 2][ 0]=0.200; blosum62[ 2][ 1]=0.400; blosum62[ 2][ 2]=1.000; blosum62[ 2][ 3]=0.500; blosum62[ 2][ 4]=0.100; blosum62[ 2][ 5]=0.400; blosum62[ 2][ 6]=0.400; blosum62[ 2][ 7]=0.400; blosum62[ 2][ 8]=0.500; blosum62[ 2][ 9]=0.100; blosum62[ 2][10]=0.100; blosum62[ 2][11]=0.400; blosum62[ 2][12]=0.200; blosum62[ 2][13]=0.100; blosum62[ 2][14]=0.200; blosum62[ 2][15]=0.500; blosum62[ 2][16]=0.400; blosum62[ 2][17]=0.000; blosum62[ 2][18]=0.200; blosum62[ 2][19]=0.100; blosum62[ 2][20]=1.000; blosum62[ 2][21]=0.400; blosum62[ 2][22]=0.300; 
	blosum62[ 3][ 0]=0.200; blosum62[ 3][ 1]=0.200; blosum62[ 3][ 2]=0.500; blosum62[ 3][ 3]=1.000; blosum62[ 3][ 4]=0.100; blosum62[ 3][ 5]=0.400; blosum62[ 3][ 6]=0.600; blosum62[ 3][ 7]=0.300; blosum62[ 3][ 8]=0.300; blosum62[ 3][ 9]=0.100; blosum62[ 3][10]=0.000; blosum62[ 3][11]=0.300; blosum62[ 3][12]=0.100; blosum62[ 3][13]=0.100; blosum62[ 3][14]=0.300; blosum62[ 3][15]=0.400; blosum62[ 3][16]=0.300; blosum62[ 3][17]=0.000; blosum62[ 3][18]=0.100; blosum62[ 3][19]=0.100; blosum62[ 3][20]=0.500; blosum62[ 3][21]=0.400; blosum62[ 3][22]=0.300; 
	blosum62[ 4][ 0]=0.308; blosum62[ 4][ 1]=0.077; blosum62[ 4][ 2]=0.077; blosum62[ 4][ 3]=0.077; blosum62[ 4][ 4]=1.000; blosum62[ 4][ 5]=0.077; blosum62[ 4][ 6]=0.000; blosum62[ 4][ 7]=0.077; blosum62[ 4][ 8]=0.077; blosum62[ 4][ 9]=0.231; blosum62[ 4][10]=0.231; blosum62[ 4][11]=0.077; blosum62[ 4][12]=0.231; blosum62[ 4][13]=0.154; blosum62[ 4][14]=0.077; blosum62[ 4][15]=0.231; blosum62[ 4][16]=0.231; blosum62[ 4][17]=0.154; blosum62[ 4][18]=0.154; blosum62[ 4][19]=0.231; blosum62[ 4][20]=0.077; blosum62[ 4][21]=0.077; blosum62[ 4][22]=0.154; 
	blosum62[ 5][ 0]=0.250; blosum62[ 5][ 1]=0.500; blosum62[ 5][ 2]=0.375; blosum62[ 5][ 3]=0.375; blosum62[ 5][ 4]=0.000; blosum62[ 5][ 5]=1.000; blosum62[ 5][ 6]=0.625; blosum62[ 5][ 7]=0.125; blosum62[ 5][ 8]=0.375; blosum62[ 5][ 9]=0.000; blosum62[ 5][10]=0.125; blosum62[ 5][11]=0.500; blosum62[ 5][12]=0.375; blosum62[ 5][13]=0.000; blosum62[ 5][14]=0.250; blosum62[ 5][15]=0.375; blosum62[ 5][16]=0.250; blosum62[ 5][17]=0.125; blosum62[ 5][18]=0.250; blosum62[ 5][19]=0.125; blosum62[ 5][20]=0.375; blosum62[ 5][21]=1.000; blosum62[ 5][22]=0.250; 
	blosum62[ 6][ 0]=0.333; blosum62[ 6][ 1]=0.444; blosum62[ 6][ 2]=0.444; blosum62[ 6][ 3]=0.667; blosum62[ 6][ 4]=0.000; blosum62[ 6][ 5]=0.667; blosum62[ 6][ 6]=1.000; blosum62[ 6][ 7]=0.222; blosum62[ 6][ 8]=0.444; blosum62[ 6][ 9]=0.111; blosum62[ 6][10]=0.111; blosum62[ 6][11]=0.556; blosum62[ 6][12]=0.222; blosum62[ 6][13]=0.111; blosum62[ 6][14]=0.333; blosum62[ 6][15]=0.444; blosum62[ 6][16]=0.333; blosum62[ 6][17]=0.111; blosum62[ 6][18]=0.222; blosum62[ 6][19]=0.222; blosum62[ 6][20]=0.444; blosum62[ 6][21]=0.667; blosum62[ 6][22]=0.333; 
	blosum62[ 7][ 0]=0.400; blosum62[ 7][ 1]=0.200; blosum62[ 7][ 2]=0.400; blosum62[ 7][ 3]=0.300; blosum62[ 7][ 4]=0.100; blosum62[ 7][ 5]=0.200; blosum62[ 7][ 6]=0.200; blosum62[ 7][ 7]=1.000; blosum62[ 7][ 8]=0.200; blosum62[ 7][ 9]=0.000; blosum62[ 7][10]=0.000; blosum62[ 7][11]=0.200; blosum62[ 7][12]=0.100; blosum62[ 7][13]=0.100; blosum62[ 7][14]=0.200; blosum62[ 7][15]=0.400; blosum62[ 7][16]=0.200; blosum62[ 7][17]=0.200; blosum62[ 7][18]=0.100; blosum62[ 7][19]=0.100; blosum62[ 7][20]=0.400; blosum62[ 7][21]=0.200; blosum62[ 7][22]=0.300; 
	blosum62[ 8][ 0]=0.091; blosum62[ 8][ 1]=0.273; blosum62[ 8][ 2]=0.364; blosum62[ 8][ 3]=0.182; blosum62[ 8][ 4]=0.000; blosum62[ 8][ 5]=0.273; blosum62[ 8][ 6]=0.273; blosum62[ 8][ 7]=0.091; blosum62[ 8][ 8]=1.000; blosum62[ 8][ 9]=0.000; blosum62[ 8][10]=0.000; blosum62[ 8][11]=0.182; blosum62[ 8][12]=0.091; blosum62[ 8][13]=0.182; blosum62[ 8][14]=0.091; blosum62[ 8][15]=0.182; blosum62[ 8][16]=0.091; blosum62[ 8][17]=0.091; blosum62[ 8][18]=0.455; blosum62[ 8][19]=0.000; blosum62[ 8][20]=0.364; blosum62[ 8][21]=0.273; blosum62[ 8][22]=0.182; 
	blosum62[ 9][ 0]=0.375; blosum62[ 9][ 1]=0.125; blosum62[ 9][ 2]=0.125; blosum62[ 9][ 3]=0.125; blosum62[ 9][ 4]=0.375; blosum62[ 9][ 5]=0.125; blosum62[ 9][ 6]=0.125; blosum62[ 9][ 7]=0.000; blosum62[ 9][ 8]=0.125; blosum62[ 9][ 9]=1.000; blosum62[ 9][10]=0.750; blosum62[ 9][11]=0.125; blosum62[ 9][12]=0.625; blosum62[ 9][13]=0.500; blosum62[ 9][14]=0.125; blosum62[ 9][15]=0.250; blosum62[ 9][16]=0.375; blosum62[ 9][17]=0.125; blosum62[ 9][18]=0.375; blosum62[ 9][19]=0.875; blosum62[ 9][20]=0.125; blosum62[ 9][21]=0.125; blosum62[ 9][22]=0.375; 
	blosum62[10][ 0]=0.375; blosum62[10][ 1]=0.250; blosum62[10][ 2]=0.125; blosum62[10][ 3]=0.000; blosum62[10][ 4]=0.375; blosum62[10][ 5]=0.250; blosum62[10][ 6]=0.125; blosum62[10][ 7]=0.000; blosum62[10][ 8]=0.125; blosum62[10][ 9]=0.750; blosum62[10][10]=1.000; blosum62[10][11]=0.250; blosum62[10][12]=0.750; blosum62[10][13]=0.500; blosum62[10][14]=0.125; blosum62[10][15]=0.250; blosum62[10][16]=0.375; blosum62[10][17]=0.250; blosum62[10][18]=0.375; blosum62[10][19]=0.625; blosum62[10][20]=0.125; blosum62[10][21]=0.250; blosum62[10][22]=0.375; 
	blosum62[11][ 0]=0.250; blosum62[11][ 1]=0.625; blosum62[11][ 2]=0.375; blosum62[11][ 3]=0.250; blosum62[11][ 4]=0.000; blosum62[11][ 5]=0.500; blosum62[11][ 6]=0.500; blosum62[11][ 7]=0.125; blosum62[11][ 8]=0.250; blosum62[11][ 9]=0.000; blosum62[11][10]=0.125; blosum62[11][11]=1.000; blosum62[11][12]=0.250; blosum62[11][13]=0.000; blosum62[11][14]=0.250; blosum62[11][15]=0.375; blosum62[11][16]=0.250; blosum62[11][17]=0.000; blosum62[11][18]=0.125; blosum62[11][19]=0.125; blosum62[11][20]=0.375; blosum62[11][21]=0.500; blosum62[11][22]=0.250; 
	blosum62[12][ 0]=0.250; blosum62[12][ 1]=0.250; blosum62[12][ 2]=0.125; blosum62[12][ 3]=0.000; blosum62[12][ 4]=0.250; blosum62[12][ 5]=0.375; blosum62[12][ 6]=0.125; blosum62[12][ 7]=0.000; blosum62[12][ 8]=0.125; blosum62[12][ 9]=0.500; blosum62[12][10]=0.625; blosum62[12][11]=0.250; blosum62[12][12]=1.000; blosum62[12][13]=0.375; blosum62[12][14]=0.125; blosum62[12][15]=0.250; blosum62[12][16]=0.250; blosum62[12][17]=0.250; blosum62[12][18]=0.250; blosum62[12][19]=0.500; blosum62[12][20]=0.125; blosum62[12][21]=0.375; blosum62[12][22]=0.250; 
	blosum62[13][ 0]=0.200; blosum62[13][ 1]=0.100; blosum62[13][ 2]=0.100; blosum62[13][ 3]=0.100; blosum62[13][ 4]=0.200; blosum62[13][ 5]=0.100; blosum62[13][ 6]=0.100; blosum62[13][ 7]=0.100; blosum62[13][ 8]=0.300; blosum62[13][ 9]=0.400; blosum62[13][10]=0.400; blosum62[13][11]=0.100; blosum62[13][12]=0.400; blosum62[13][13]=1.000; blosum62[13][14]=0.000; blosum62[13][15]=0.200; blosum62[13][16]=0.200; blosum62[13][17]=0.500; blosum62[13][18]=0.700; blosum62[13][19]=0.300; blosum62[13][20]=0.100; blosum62[13][21]=0.100; blosum62[13][22]=0.300; 
	blosum62[14][ 0]=0.273; blosum62[14][ 1]=0.182; blosum62[14][ 2]=0.182; blosum62[14][ 3]=0.273; blosum62[14][ 4]=0.091; blosum62[14][ 5]=0.273; blosum62[14][ 6]=0.273; blosum62[14][ 7]=0.182; blosum62[14][ 8]=0.182; blosum62[14][ 9]=0.091; blosum62[14][10]=0.091; blosum62[14][11]=0.273; blosum62[14][12]=0.182; blosum62[14][13]=0.000; blosum62[14][14]=1.000; blosum62[14][15]=0.273; blosum62[14][16]=0.273; blosum62[14][17]=0.000; blosum62[14][18]=0.091; blosum62[14][19]=0.182; blosum62[14][20]=0.182; blosum62[14][21]=0.273; blosum62[14][22]=0.182; 
	blosum62[15][ 0]=0.571; blosum62[15][ 1]=0.286; blosum62[15][ 2]=0.571; blosum62[15][ 3]=0.429; blosum62[15][ 4]=0.286; blosum62[15][ 5]=0.429; blosum62[15][ 6]=0.429; blosum62[15][ 7]=0.429; blosum62[15][ 8]=0.286; blosum62[15][ 9]=0.143; blosum62[15][10]=0.143; blosum62[15][11]=0.429; blosum62[15][12]=0.286; blosum62[15][13]=0.143; blosum62[15][14]=0.286; blosum62[15][15]=1.000; blosum62[15][16]=0.571; blosum62[15][17]=0.000; blosum62[15][18]=0.143; blosum62[15][19]=0.143; blosum62[15][20]=0.571; blosum62[15][21]=0.429; blosum62[15][22]=0.429; 
	blosum62[16][ 0]=0.286; blosum62[16][ 1]=0.143; blosum62[16][ 2]=0.286; blosum62[16][ 3]=0.143; blosum62[16][ 4]=0.143; blosum62[16][ 5]=0.143; blosum62[16][ 6]=0.143; blosum62[16][ 7]=0.000; blosum62[16][ 8]=0.000; blosum62[16][ 9]=0.143; blosum62[16][10]=0.143; blosum62[16][11]=0.143; blosum62[16][12]=0.143; blosum62[16][13]=0.000; blosum62[16][14]=0.143; blosum62[16][15]=0.429; blosum62[16][16]=1.000; blosum62[16][17]=0.000; blosum62[16][18]=0.000; blosum62[16][19]=0.286; blosum62[16][20]=0.286; blosum62[16][21]=0.143; blosum62[16][22]=0.286; 
	blosum62[17][ 0]=0.067; blosum62[17][ 1]=0.067; blosum62[17][ 2]=0.000; blosum62[17][ 3]=0.000; blosum62[17][ 4]=0.133; blosum62[17][ 5]=0.133; blosum62[17][ 6]=0.067; blosum62[17][ 7]=0.133; blosum62[17][ 8]=0.133; blosum62[17][ 9]=0.067; blosum62[17][10]=0.133; blosum62[17][11]=0.067; blosum62[17][12]=0.200; blosum62[17][13]=0.333; blosum62[17][14]=0.000; blosum62[17][15]=0.067; blosum62[17][16]=0.133; blosum62[17][17]=1.000; blosum62[17][18]=0.400; blosum62[17][19]=0.067; blosum62[17][20]=0.000; blosum62[17][21]=0.133; blosum62[17][22]=0.133; 
	blosum62[18][ 0]=0.100; blosum62[18][ 1]=0.100; blosum62[18][ 2]=0.100; blosum62[18][ 3]=0.000; blosum62[18][ 4]=0.100; blosum62[18][ 5]=0.200; blosum62[18][ 6]=0.100; blosum62[18][ 7]=0.000; blosum62[18][ 8]=0.500; blosum62[18][ 9]=0.200; blosum62[18][10]=0.200; blosum62[18][11]=0.100; blosum62[18][12]=0.200; blosum62[18][13]=0.600; blosum62[18][14]=0.000; blosum62[18][15]=0.100; blosum62[18][16]=0.100; blosum62[18][17]=0.500; blosum62[18][18]=1.000; blosum62[18][19]=0.200; blosum62[18][20]=0.100; blosum62[18][21]=0.200; blosum62[18][22]=0.200; 
	blosum62[19][ 0]=0.429; blosum62[19][ 1]=0.000; blosum62[19][ 2]=0.000; blosum62[19][ 3]=0.000; blosum62[19][ 4]=0.286; blosum62[19][ 5]=0.143; blosum62[19][ 6]=0.143; blosum62[19][ 7]=0.000; blosum62[19][ 8]=0.000; blosum62[19][ 9]=0.857; blosum62[19][10]=0.571; blosum62[19][11]=0.143; blosum62[19][12]=0.571; blosum62[19][13]=0.286; blosum62[19][14]=0.143; blosum62[19][15]=0.143; blosum62[19][16]=0.429; blosum62[19][17]=0.000; blosum62[19][18]=0.286; blosum62[19][19]=1.000; blosum62[19][20]=0.000; blosum62[19][21]=0.143; blosum62[19][22]=0.286; 
	blosum62[20][ 0]=0.200; blosum62[20][ 1]=0.400; blosum62[20][ 2]=1.000; blosum62[20][ 3]=0.500; blosum62[20][ 4]=0.100; blosum62[20][ 5]=0.400; blosum62[20][ 6]=0.400; blosum62[20][ 7]=0.400; blosum62[20][ 8]=0.500; blosum62[20][ 9]=0.100; blosum62[20][10]=0.100; blosum62[20][11]=0.400; blosum62[20][12]=0.200; blosum62[20][13]=0.100; blosum62[20][14]=0.200; blosum62[20][15]=0.500; blosum62[20][16]=0.400; blosum62[20][17]=0.000; blosum62[20][18]=0.200; blosum62[20][19]=0.100; blosum62[20][20]=1.000; blosum62[20][21]=0.400; blosum62[20][22]=0.300; 
	blosum62[21][ 0]=0.250; blosum62[21][ 1]=0.500; blosum62[21][ 2]=0.375; blosum62[21][ 3]=0.375; blosum62[21][ 4]=0.000; blosum62[21][ 5]=1.000; blosum62[21][ 6]=0.625; blosum62[21][ 7]=0.125; blosum62[21][ 8]=0.375; blosum62[21][ 9]=0.000; blosum62[21][10]=0.125; blosum62[21][11]=0.500; blosum62[21][12]=0.375; blosum62[21][13]=0.000; blosum62[21][14]=0.250; blosum62[21][15]=0.375; blosum62[21][16]=0.250; blosum62[21][17]=0.125; blosum62[21][18]=0.250; blosum62[21][19]=0.125; blosum62[21][20]=0.375; blosum62[21][21]=1.000; blosum62[21][22]=0.250; 
	blosum62[22][ 0]=1.000; blosum62[22][ 1]=0.500; blosum62[22][ 2]=0.500; blosum62[22][ 3]=0.500; blosum62[22][ 4]=0.000; blosum62[22][ 5]=0.500; blosum62[22][ 6]=0.500; blosum62[22][ 7]=0.500; blosum62[22][ 8]=0.500; blosum62[22][ 9]=0.500; blosum62[22][10]=0.500; blosum62[22][11]=0.500; blosum62[22][12]=0.500; blosum62[22][13]=0.500; blosum62[22][14]=0.000; blosum62[22][15]=1.000; blosum62[22][16]=1.000; blosum62[22][17]=0.000; blosum62[22][18]=0.500; blosum62[22][19]=0.500; blosum62[22][20]=0.500; blosum62[22][21]=0.500; blosum62[22][22]=0.500; 



}
